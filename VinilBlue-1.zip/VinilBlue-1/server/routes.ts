import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertUserSchema, insertVideoSchema, insertCommentSchema, insertLikeSchema, insertFollowSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Users
  app.get("/api/users/:id", async (req, res) => {
    const { id } = req.params;
    const user = await storage.getUser(id);
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }
    res.json(user);
  });

  app.get("/api/users/username/:username", async (req, res) => {
    const { username } = req.params;
    const user = await storage.getUserByUsername(username);
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }
    res.json(user);
  });

  app.post("/api/users", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      const user = await storage.createUser(userData);
      res.status(201).json(user);
    } catch (error) {
      res.status(400).json({ message: "Invalid user data" });
    }
  });

  app.patch("/api/users/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const updates = insertUserSchema.partial().parse(req.body);
      const user = await storage.updateUser(id, updates);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      res.json(user);
    } catch (error) {
      res.status(400).json({ message: "Invalid user data" });
    }
  });

  // Videos
  app.get("/api/videos", async (req, res) => {
    const limit = parseInt(req.query.limit as string) || 20;
    const offset = parseInt(req.query.offset as string) || 0;
    const videos = await storage.getVideos(limit, offset);
    res.json(videos);
  });

  app.get("/api/videos/:id", async (req, res) => {
    const { id } = req.params;
    const video = await storage.getVideo(id);
    if (!video) {
      return res.status(404).json({ message: "Video not found" });
    }
    res.json(video);
  });

  app.get("/api/users/:userId/videos", async (req, res) => {
    const { userId } = req.params;
    const videos = await storage.getVideosByUser(userId);
    res.json(videos);
  });

  app.post("/api/videos", async (req, res) => {
    try {
      const videoData = insertVideoSchema.parse(req.body);
      const video = await storage.createVideo(videoData);
      res.status(201).json(video);
    } catch (error) {
      res.status(400).json({ message: "Invalid video data" });
    }
  });

  // Comments
  app.get("/api/videos/:videoId/comments", async (req, res) => {
    const { videoId } = req.params;
    const comments = await storage.getCommentsByVideo(videoId);
    res.json(comments);
  });

  app.post("/api/comments", async (req, res) => {
    try {
      const commentData = insertCommentSchema.parse(req.body);
      const comment = await storage.createComment(commentData);
      
      // Update video comment count
      const video = await storage.getVideo(commentData.videoId);
      if (video) {
        await storage.updateVideoStats(video.id, { 
          commentsCount: video.commentsCount + 1 
        });
      }
      
      res.status(201).json(comment);
    } catch (error) {
      res.status(400).json({ message: "Invalid comment data" });
    }
  });

  // Likes
  app.post("/api/likes", async (req, res) => {
    try {
      const likeData = insertLikeSchema.parse(req.body);
      
      // Check if already liked
      const existingLike = await storage.getLike(likeData.userId, likeData.videoId);
      if (existingLike) {
        return res.status(400).json({ message: "Already liked" });
      }
      
      const like = await storage.createLike(likeData);
      
      // Update video like count
      const video = await storage.getVideo(likeData.videoId);
      if (video) {
        await storage.updateVideoStats(video.id, { 
          likesCount: video.likesCount + 1 
        });
      }
      
      res.status(201).json(like);
    } catch (error) {
      res.status(400).json({ message: "Invalid like data" });
    }
  });

  app.delete("/api/likes/:userId/:videoId", async (req, res) => {
    const { userId, videoId } = req.params;
    const success = await storage.deleteLike(userId, videoId);
    if (!success) {
      return res.status(404).json({ message: "Like not found" });
    }
    
    // Update video like count
    const video = await storage.getVideo(videoId);
    if (video && video.likesCount > 0) {
      await storage.updateVideoStats(video.id, { 
        likesCount: video.likesCount - 1 
      });
    }
    
    res.status(204).send();
  });

  // Follows
  app.post("/api/follows", async (req, res) => {
    try {
      const followData = insertFollowSchema.parse(req.body);
      
      // Check if already following
      const existingFollow = await storage.getFollow(followData.followerId, followData.followingId);
      if (existingFollow) {
        return res.status(400).json({ message: "Already following" });
      }
      
      const follow = await storage.createFollow(followData);
      res.status(201).json(follow);
    } catch (error) {
      res.status(400).json({ message: "Invalid follow data" });
    }
  });

  app.delete("/api/follows/:followerId/:followingId", async (req, res) => {
    const { followerId, followingId } = req.params;
    const success = await storage.deleteFollow(followerId, followingId);
    if (!success) {
      return res.status(404).json({ message: "Follow not found" });
    }
    res.status(204).send();
  });

  app.get("/api/users/:userId/followers", async (req, res) => {
    const { userId } = req.params;
    const followers = await storage.getFollowers(userId);
    res.json(followers);
  });

  app.get("/api/users/:userId/following", async (req, res) => {
    const { userId } = req.params;
    const following = await storage.getFollowing(userId);
    res.json(following);
  });

  const httpServer = createServer(app);
  return httpServer;
}
