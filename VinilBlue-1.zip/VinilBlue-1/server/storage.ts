import { type User, type InsertUser, type Video, type InsertVideo, type Comment, type InsertComment, type Like, type InsertLike, type Follow, type InsertFollow } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Users
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: string, updates: Partial<InsertUser>): Promise<User | undefined>;
  
  // Videos
  getVideo(id: string): Promise<Video | undefined>;
  getVideos(limit?: number, offset?: number): Promise<Video[]>;
  getVideosByUser(userId: string): Promise<Video[]>;
  createVideo(video: InsertVideo): Promise<Video>;
  updateVideoStats(id: string, stats: { likesCount?: number; commentsCount?: number; sharesCount?: number; viewsCount?: number }): Promise<Video | undefined>;
  
  // Comments
  getCommentsByVideo(videoId: string): Promise<Comment[]>;
  createComment(comment: InsertComment): Promise<Comment>;
  
  // Likes
  getLike(userId: string, videoId: string): Promise<Like | undefined>;
  createLike(like: InsertLike): Promise<Like>;
  deleteLike(userId: string, videoId: string): Promise<boolean>;
  
  // Follows
  getFollow(followerId: string, followingId: string): Promise<Follow | undefined>;
  createFollow(follow: InsertFollow): Promise<Follow>;
  deleteFollow(followerId: string, followingId: string): Promise<boolean>;
  getFollowers(userId: string): Promise<Follow[]>;
  getFollowing(userId: string): Promise<Follow[]>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private videos: Map<string, Video>;
  private comments: Map<string, Comment>;
  private likes: Map<string, Like>;
  private follows: Map<string, Follow>;

  constructor() {
    this.users = new Map();
    this.videos = new Map();
    this.comments = new Map();
    this.likes = new Map();
    this.follows = new Map();
    
    // Initialize with some demo data
    this.initializeDemoData();
  }

  private initializeDemoData() {
    // Create demo users
    const demoUsers = [
      {
        id: "user1",
        username: "maria_dance",
        displayName: "Maria Santos",
        bio: "Dançarina profissional 💃✨ #dança #tutorial #vibes",
        avatar: "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=150&h=150&fit=crop&crop=face",
        followersCount: 2300,
        followingCount: 128,
        likesCount: 8900,
        createdAt: new Date(),
      },
      {
        id: "user2", 
        username: "art_creator",
        displayName: "Carlos Arte",
        bio: "Artista urbano 🎨 #arte #streetart #criatividade",
        avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face",
        followersCount: 1800,
        followingCount: 95,
        likesCount: 12500,
        createdAt: new Date(),
      },
      {
        id: "user3",
        username: "joao_silva",
        displayName: "João Silva", 
        bio: "Criador de conteúdo • Amante da música • Sempre em busca de novos ritmos 🎵",
        avatar: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&h=150&fit=crop&crop=face",
        followersCount: 856,
        followingCount: 234,
        likesCount: 3200,
        createdAt: new Date(),
      }
    ];

    demoUsers.forEach(user => this.users.set(user.id, user as User));

    // Create demo videos
    const demoVideos = [
      {
        id: "video1",
        userId: "user1",
        description: "Novo passo que aprendi hoje! 💃✨ #dança #tutorial #vibes",
        videoUrl: "https://example.com/video1.mp4",
        thumbnailUrl: "https://images.unsplash.com/photo-1516280440614-37939bbacd81?w=400&h=800&fit=crop",
        musicTitle: "Som Original",
        musicArtist: "maria_dance",
        likesCount: 8200,
        commentsCount: 245,
        sharesCount: 89,
        viewsCount: 25600,
        createdAt: new Date(),
      },
      {
        id: "video2", 
        userId: "user2",
        description: "Transformando paredes em arte! 🎨 #arte #streetart #criatividade",
        videoUrl: "https://example.com/video2.mp4", 
        thumbnailUrl: "https://images.unsplash.com/photo-1541961017774-22349e4a1262?w=400&h=800&fit=crop",
        musicTitle: "Beat Underground",
        musicArtist: "DJ Mix",
        likesCount: 12500,
        commentsCount: 892,
        sharesCount: 156,
        viewsCount: 45200,
        createdAt: new Date(),
      }
    ];

    demoVideos.forEach(video => this.videos.set(video.id, video as Video));

    // Create demo comments
    const demoComments = [
      {
        id: "comment1",
        videoId: "video1",
        userId: "user2", 
        text: "Que movimento incrível! Como faz essa transição?",
        likesCount: 12,
        createdAt: new Date(Date.now() - 2 * 60 * 60 * 1000), // 2 hours ago
      },
      {
        id: "comment2",
        videoId: "video1",
        userId: "user3",
        text: "Tutorial pleeease! 🙏",
        likesCount: 8,
        createdAt: new Date(Date.now() - 1 * 60 * 60 * 1000), // 1 hour ago
      }
    ];

    demoComments.forEach(comment => this.comments.set(comment.id, comment as Comment));
  }

  // User methods
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = {
      ...insertUser,
      id,
      followersCount: 0,
      followingCount: 0,
      likesCount: 0,
      createdAt: new Date(),
    };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: string, updates: Partial<InsertUser>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...updates };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  // Video methods
  async getVideo(id: string): Promise<Video | undefined> {
    return this.videos.get(id);
  }

  async getVideos(limit: number = 20, offset: number = 0): Promise<Video[]> {
    const allVideos = Array.from(this.videos.values())
      .sort((a, b) => b.createdAt!.getTime() - a.createdAt!.getTime());
    return allVideos.slice(offset, offset + limit);
  }

  async getVideosByUser(userId: string): Promise<Video[]> {
    return Array.from(this.videos.values())
      .filter(video => video.userId === userId)
      .sort((a, b) => b.createdAt!.getTime() - a.createdAt!.getTime());
  }

  async createVideo(insertVideo: InsertVideo): Promise<Video> {
    const id = randomUUID();
    const video: Video = {
      ...insertVideo,
      id,
      likesCount: 0,
      commentsCount: 0,
      sharesCount: 0,
      viewsCount: 0,
      createdAt: new Date(),
    };
    this.videos.set(id, video);
    return video;
  }

  async updateVideoStats(id: string, stats: { likesCount?: number; commentsCount?: number; sharesCount?: number; viewsCount?: number }): Promise<Video | undefined> {
    const video = this.videos.get(id);
    if (!video) return undefined;
    
    const updatedVideo = { ...video, ...stats };
    this.videos.set(id, updatedVideo);
    return updatedVideo;
  }

  // Comment methods
  async getCommentsByVideo(videoId: string): Promise<Comment[]> {
    return Array.from(this.comments.values())
      .filter(comment => comment.videoId === videoId)
      .sort((a, b) => b.createdAt!.getTime() - a.createdAt!.getTime());
  }

  async createComment(insertComment: InsertComment): Promise<Comment> {
    const id = randomUUID();
    const comment: Comment = {
      ...insertComment,
      id,
      likesCount: 0,
      createdAt: new Date(),
    };
    this.comments.set(id, comment);
    return comment;
  }

  // Like methods
  async getLike(userId: string, videoId: string): Promise<Like | undefined> {
    return Array.from(this.likes.values()).find(
      like => like.userId === userId && like.videoId === videoId
    );
  }

  async createLike(insertLike: InsertLike): Promise<Like> {
    const id = randomUUID();
    const like: Like = {
      ...insertLike,
      id,
      createdAt: new Date(),
    };
    this.likes.set(id, like);
    return like;
  }

  async deleteLike(userId: string, videoId: string): Promise<boolean> {
    const like = await this.getLike(userId, videoId);
    if (!like) return false;
    
    return this.likes.delete(like.id);
  }

  // Follow methods
  async getFollow(followerId: string, followingId: string): Promise<Follow | undefined> {
    return Array.from(this.follows.values()).find(
      follow => follow.followerId === followerId && follow.followingId === followingId
    );
  }

  async createFollow(insertFollow: InsertFollow): Promise<Follow> {
    const id = randomUUID();
    const follow: Follow = {
      ...insertFollow,
      id,
      createdAt: new Date(),
    };
    this.follows.set(id, follow);
    return follow;
  }

  async deleteFollow(followerId: string, followingId: string): Promise<boolean> {
    const follow = await this.getFollow(followerId, followingId);
    if (!follow) return false;
    
    return this.follows.delete(follow.id);
  }

  async getFollowers(userId: string): Promise<Follow[]> {
    return Array.from(this.follows.values()).filter(follow => follow.followingId === userId);
  }

  async getFollowing(userId: string): Promise<Follow[]> {
    return Array.from(this.follows.values()).filter(follow => follow.followerId === userId);
  }
}

export const storage = new MemStorage();
