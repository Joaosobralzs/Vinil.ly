import { VideoFeed } from "@/components/video-feed";
import { TopBar } from "@/components/top-bar";
import { BottomNavigation } from "@/components/bottom-navigation";

export default function Home() {
  return (
    <div className="relative w-full h-screen bg-black overflow-hidden">
      <VideoFeed />
      <TopBar />
      <BottomNavigation />
    </div>
  );
}
