import { useState } from "react";
import { ArrowLeft, Edit, Share } from "lucide-react";
import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { EditProfileModal } from "@/components/edit-profile-modal";
import { BottomNavigation } from "@/components/bottom-navigation";
import type { User, Video } from "@shared/schema";

export default function Profile() {
  const [, setLocation] = useLocation();
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<'videos' | 'liked'>('videos');

  // Mock current user - in real app this would come from auth context
  const currentUserId = "user3";

  const { data: user } = useQuery<User>({
    queryKey: ['/api/users', currentUserId],
    queryFn: async () => {
      const response = await fetch(`/api/users/${currentUserId}`);
      return response.json();
    }
  });

  const { data: videos = [] } = useQuery<Video[]>({
    queryKey: ['/api/users', currentUserId, 'videos'],
    queryFn: async () => {
      const response = await fetch(`/api/users/${currentUserId}/videos`);
      return response.json();
    },
    enabled: !!user
  });

  const formatCount = (count: number) => {
    if (count >= 1000000) return `${(count / 1000000).toFixed(1)}M`;
    if (count >= 1000) return `${(count / 1000).toFixed(1)}K`;
    return count.toString();
  };

  if (!user) {
    return (
      <div className="relative w-full h-screen bg-black flex items-center justify-center">
        <p className="text-white text-lg">Carregando perfil...</p>
        <BottomNavigation />
      </div>
    );
  }

  return (
    <div className="relative w-full h-screen bg-black overflow-hidden">
      <div className="h-full overflow-y-auto pb-20">
        {/* Profile Header */}
        <div className="relative">
          {/* Profile cover background */}
          <div className="h-32 bg-gradient-to-br from-vinil-blue to-vinil-dark-blue"></div>
          
          {/* Back button */}
          <button 
            className="absolute top-12 left-4 p-2 hover:bg-black hover:bg-opacity-50 rounded-full transition-colors"
            onClick={() => setLocation("/")}
          >
            <ArrowLeft className="w-6 h-6 text-white" />
          </button>
          
          {/* Profile Info */}
          <div className="px-6 pb-6">
            {/* Profile picture */}
            <div className="relative -mt-16 mb-4">
              <img 
                src={user.avatar || `https://api.dicebear.com/7.x/avataaars/svg?seed=${user.username}`}
                alt="Sua foto" 
                className="w-32 h-32 rounded-full border-4 border-black mx-auto object-cover" 
              />
              <button 
                className="absolute bottom-0 right-1/2 transform translate-x-16 translate-y-2 bg-vinil-blue text-white rounded-full p-2 hover:bg-vinil-dark-blue transition-colors"
                onClick={() => setIsEditModalOpen(true)}
              >
                <Edit className="w-4 h-4" />
              </button>
            </div>
            
            {/* User info */}
            <div className="text-center mb-6">
              <h2 className="text-white text-2xl font-bold mb-1">{user.displayName}</h2>
              <p className="text-gray-400 mb-1">@{user.username}</p>
              {user.bio && (
                <p className="text-gray-300 text-sm max-w-xs mx-auto">{user.bio}</p>
              )}
            </div>
            
            {/* Stats */}
            <div className="flex justify-center space-x-8 mb-6">
              <div className="text-center">
                <div className="text-white text-xl font-bold">{formatCount(user.followingCount)}</div>
                <div className="text-gray-400 text-sm">Seguindo</div>
              </div>
              <div className="text-center">
                <div className="text-white text-xl font-bold">{formatCount(user.followersCount)}</div>
                <div className="text-gray-400 text-sm">Seguidores</div>
              </div>
              <div className="text-center">
                <div className="text-white text-xl font-bold">{formatCount(user.likesCount)}</div>
                <div className="text-gray-400 text-sm">Curtidas</div>
              </div>
            </div>
            
            {/* Action buttons */}
            <div className="flex space-x-4">
              <Button 
                className="flex-1 bg-vinil-blue hover:bg-vinil-dark-blue text-white rounded-xl font-semibold"
                onClick={() => setIsEditModalOpen(true)}
              >
                Editar Perfil
              </Button>
              <Button 
                variant="secondary"
                className="flex-1 bg-gray-800 hover:bg-gray-700 text-white rounded-xl font-semibold"
              >
                <Share className="w-4 h-4 mr-2" />
                Compartilhar
              </Button>
            </div>
          </div>
        </div>
        
        {/* Videos Grid */}
        <div className="px-6">
          <div className="flex border-b border-gray-800 mb-6">
            <button 
              className={`flex-1 py-3 font-medium border-b-2 ${
                activeTab === 'videos' 
                  ? 'text-vinil-blue border-vinil-blue' 
                  : 'text-gray-400 border-transparent'
              }`}
              onClick={() => setActiveTab('videos')}
            >
              Vídeos ({videos.length})
            </button>
            <button 
              className={`flex-1 py-3 font-medium border-b-2 ${
                activeTab === 'liked' 
                  ? 'text-vinil-blue border-vinil-blue' 
                  : 'text-gray-400 border-transparent'
              }`}
              onClick={() => setActiveTab('liked')}
            >
              Curtidos
            </button>
          </div>
          
          {activeTab === 'videos' && (
            <div className="grid grid-cols-3 gap-1">
              {videos.length === 0 ? (
                <div className="col-span-3 text-center py-8">
                  <p className="text-gray-400">Nenhum vídeo ainda</p>
                  <p className="text-gray-500 text-sm mt-1">Seus vídeos aparecerão aqui</p>
                </div>
              ) : (
                videos.map((video) => (
                  <div key={video.id} className="relative aspect-[9/16] bg-gray-800 rounded-lg overflow-hidden">
                    <img 
                      src={video.thumbnailUrl}
                      alt="Video thumbnail" 
                      className="w-full h-full object-cover" 
                    />
                    <div className="absolute bottom-2 right-2 bg-black bg-opacity-70 text-white text-xs px-2 py-1 rounded">
                      {formatCount(video.viewsCount)}
                    </div>
                  </div>
                ))
              )}
            </div>
          )}

          {activeTab === 'liked' && (
            <div className="text-center py-8">
              <p className="text-gray-400">Vídeos curtidos aparecerão aqui</p>
              <p className="text-gray-500 text-sm mt-1">Curta vídeos para vê-los nesta aba</p>
            </div>
          )}
        </div>
      </div>

      <EditProfileModal
        user={user}
        isOpen={isEditModalOpen}
        onClose={() => setIsEditModalOpen(false)}
      />
      
      <BottomNavigation />
    </div>
  );
}
