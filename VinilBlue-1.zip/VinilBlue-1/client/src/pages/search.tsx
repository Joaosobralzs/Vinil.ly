import { useState } from "react";
import { ArrowLeft, Search, Clock, X } from "lucide-react";
import { useLocation } from "wouter";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { BottomNavigation } from "@/components/bottom-navigation";

export default function SearchPage() {
  const [, setLocation] = useLocation();
  const [searchTerm, setSearchTerm] = useState("");

  const recentSearches = [
    "dança",
    "música eletrônica",
    "tutorial",
  ];

  const trendingHashtags = [
    { tag: "#dançatiktok", videos: "2.1M" },
    { tag: "#musicanova", videos: "892K" },
    { tag: "#tutorial", videos: "1.5M" },
    { tag: "#artedigital", videos: "645K" },
    { tag: "#comédia", videos: "3.2M" },
  ];

  const removeRecentSearch = (searchToRemove: string) => {
    // In a real app, this would update the user's search history
    console.log("Removing search:", searchToRemove);
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchTerm.trim()) {
      console.log("Searching for:", searchTerm);
      // In a real app, this would perform the search
    }
  };

  return (
    <div className="relative w-full h-screen bg-black overflow-hidden">
      <div className="h-full flex flex-col pb-20">
        {/* Search Header */}
        <div className="flex items-center p-4 pt-12 space-x-4 bg-black border-b border-gray-800">
          <Button 
            variant="ghost" 
            size="sm"
            className="p-2 hover:bg-gray-800 text-white"
            onClick={() => setLocation("/")}
          >
            <ArrowLeft className="w-6 h-6" />
          </Button>
          
          <form onSubmit={handleSearch} className="flex-1">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
              <Input
                type="text"
                placeholder="Buscar no vinil.ly"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full bg-gray-800 text-white placeholder-gray-400 pl-10 pr-4 py-3 rounded-xl border-0 focus:ring-2 focus:ring-vinil-blue focus:bg-gray-700"
                autoFocus
              />
            </div>
          </form>
        </div>
        
        {/* Search Results/Content */}
        <div className="flex-1 overflow-y-auto p-4">
          {searchTerm ? (
            // Search Results
            <div className="space-y-4">
              <h3 className="text-white font-semibold mb-3">
                Resultados para "{searchTerm}"
              </h3>
              <div className="text-center py-8">
                <p className="text-gray-400">Nenhum resultado encontrado</p>
                <p className="text-gray-500 text-sm mt-1">
                  Tente buscar por outros termos
                </p>
              </div>
            </div>
          ) : (
            // Default Search Content
            <div className="space-y-6">
              {/* Recent searches */}
              {recentSearches.length > 0 && (
                <div>
                  <h3 className="text-white font-semibold mb-3">Buscas Recentes</h3>
                  <div className="space-y-3">
                    {recentSearches.map((search, index) => (
                      <div key={index} className="flex items-center justify-between">
                        <button 
                          className="flex items-center space-x-3 flex-1 text-left hover:bg-gray-800 hover:bg-opacity-50 rounded-lg p-2 transition-colors"
                          onClick={() => setSearchTerm(search)}
                        >
                          <Clock className="w-5 h-5 text-gray-400" />
                          <span className="text-gray-300">{search}</span>
                        </button>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="p-1 hover:bg-gray-800 text-gray-400 hover:text-white"
                          onClick={() => removeRecentSearch(search)}
                        >
                          <X className="w-4 h-4" />
                        </Button>
                      </div>
                    ))}
                  </div>
                </div>
              )}
              
              {/* Trending hashtags */}
              <div>
                <h3 className="text-white font-semibold mb-3">Hashtags em Alta</h3>
                <div className="space-y-3">
                  {trendingHashtags.map((hashtag, index) => (
                    <button
                      key={index}
                      className="flex items-center space-x-3 w-full text-left hover:bg-gray-800 hover:bg-opacity-50 rounded-lg p-3 transition-colors"
                      onClick={() => setSearchTerm(hashtag.tag)}
                    >
                      <div className="w-8 h-8 bg-vinil-blue rounded-lg flex items-center justify-center">
                        <span className="text-white font-bold text-sm">#</span>
                      </div>
                      <div className="flex-1">
                        <div className="text-white font-medium">{hashtag.tag}</div>
                        <div className="text-gray-400 text-sm">{hashtag.videos} vídeos</div>
                      </div>
                    </button>
                  ))}
                </div>
              </div>
              
              {/* Popular creators */}
              <div>
                <h3 className="text-white font-semibold mb-3">Criadores Populares</h3>
                <div className="space-y-3">
                  {[
                    {
                      username: "maria_dance",
                      name: "Maria Santos",
                      followers: "2.3K",
                      avatar: "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=50&h=50&fit=crop&crop=face"
                    },
                    {
                      username: "art_creator", 
                      name: "Carlos Arte",
                      followers: "1.8K",
                      avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=50&h=50&fit=crop&crop=face"
                    }
                  ].map((creator, index) => (
                    <div key={index} className="flex items-center justify-between hover:bg-gray-800 hover:bg-opacity-50 rounded-lg p-3 transition-colors">
                      <div className="flex items-center space-x-3">
                        <img 
                          src={creator.avatar}
                          alt={creator.name}
                          className="w-10 h-10 rounded-full object-cover"
                        />
                        <div>
                          <div className="text-white font-medium">{creator.name}</div>
                          <div className="text-gray-400 text-sm">@{creator.username}</div>
                        </div>
                      </div>
                      <div className="text-gray-400 text-sm">{creator.followers} seguidores</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
      
      <BottomNavigation />
    </div>
  );
}
