import { useState } from "react";
import { ArrowLeft, Video, Image as ImageIcon, RotateCcw, Zap, Sparkles, Filter } from "lucide-react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { BottomNavigation } from "@/components/bottom-navigation";

export default function Create() {
  const [, setLocation] = useLocation();
  const [isRecording, setIsRecording] = useState(false);
  const [recordTime, setRecordTime] = useState(0);

  // Mock timer for recording
  React.useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isRecording) {
      interval = setInterval(() => {
        setRecordTime(prev => prev + 1);
      }, 1000);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isRecording]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleRecord = () => {
    if (isRecording) {
      setIsRecording(false);
      setRecordTime(0);
      // In a real app, this would stop recording and process the video
    } else {
      setIsRecording(true);
      setRecordTime(0);
      // In a real app, this would start recording
    }
  };

  const handleNext = () => {
    // In a real app, this would go to the video editing/posting screen
    console.log("Going to next step");
  };

  return (
    <div className="relative w-full h-screen bg-black overflow-hidden">
      <div className="h-full flex flex-col">
        {/* Create Header */}
        <div className="flex items-center justify-between p-4 pt-12 bg-black border-b border-gray-800">
          <Button 
            variant="ghost"
            className="text-white hover:text-vinil-blue"
            onClick={() => setLocation("/")}
          >
            Cancelar
          </Button>
          <h2 className="text-white font-semibold text-lg">Criar Vídeo</h2>
          <Button 
            variant="ghost"
            className="text-vinil-blue font-semibold hover:text-vinil-dark-blue"
            onClick={handleNext}
            disabled={recordTime === 0}
          >
            Próximo
          </Button>
        </div>
        
        {/* Camera/Upload Area */}
        <div className="flex-1 relative bg-gray-900">
          {/* Camera preview placeholder */}
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="text-center space-y-4">
              <div className="w-24 h-24 bg-vinil-blue bg-opacity-20 rounded-full flex items-center justify-center mx-auto">
                <Video className="w-12 h-12 text-vinil-blue" />
              </div>
              <div className="space-y-2">
                <h3 className="text-white font-medium">Toque para gravar</h3>
                <p className="text-gray-400 text-sm">Ou selecione um vídeo da galeria</p>
              </div>
            </div>
          </div>
          
          {/* Recording indicator */}
          {isRecording && (
            <div className="absolute top-8 left-1/2 transform -translate-x-1/2 bg-red-500 px-4 py-2 rounded-full flex items-center space-x-2">
              <div className="w-3 h-3 bg-white rounded-full animate-pulse"></div>
              <span className="text-white font-mono text-sm">REC</span>
            </div>
          )}
          
          {/* Recording controls */}
          <div className="absolute bottom-8 left-0 right-0 flex items-center justify-center space-x-8">
            {/* Gallery button */}
            <Button
              variant="ghost"
              size="lg"
              className="w-12 h-12 bg-gray-800 hover:bg-gray-700 rounded-xl"
            >
              <ImageIcon className="w-6 h-6 text-white" />
            </Button>
            
            {/* Record button */}
            <button 
              className={`w-20 h-20 rounded-full flex items-center justify-center transition-colors ${
                isRecording 
                  ? 'bg-red-600 hover:bg-red-700' 
                  : 'bg-red-500 hover:bg-red-600'
              }`}
              onClick={handleRecord}
            >
              <div className={`rounded-full transition-all ${
                isRecording 
                  ? 'w-8 h-8 bg-red-800' 
                  : 'w-16 h-16 bg-red-600'
              }`}></div>
            </button>
            
            {/* Switch camera */}
            <Button
              variant="ghost"
              size="lg"
              className="w-12 h-12 bg-gray-800 hover:bg-gray-700 rounded-xl"
            >
              <RotateCcw className="w-6 h-6 text-white" />
            </Button>
          </div>
          
          {/* Side controls */}
          <div className="absolute right-4 top-1/2 transform -translate-y-1/2 space-y-6">
            {/* Speed */}
            <button className="flex flex-col items-center space-y-1 p-2 hover:bg-gray-800 hover:bg-opacity-50 rounded-lg transition-colors">
              <Zap className="w-8 h-8 text-white" />
              <span className="text-white text-xs">1x</span>
            </button>
            
            {/* Beauty */}
            <button className="flex flex-col items-center space-y-1 p-2 hover:bg-gray-800 hover:bg-opacity-50 rounded-lg transition-colors">
              <Sparkles className="w-8 h-8 text-white" />
              <span className="text-white text-xs">Beauty</span>
            </button>
            
            {/* Filters */}
            <button className="flex flex-col items-center space-y-1 p-2 hover:bg-gray-800 hover:bg-opacity-50 rounded-lg transition-colors">
              <Filter className="w-8 h-8 text-white" />
              <span className="text-white text-xs">Filtros</span>
            </button>
          </div>
        </div>
        
        {/* Timer/Duration */}
        <div className="absolute top-20 left-1/2 transform -translate-x-1/2 bg-black bg-opacity-70 px-4 py-2 rounded-full">
          <span className="text-white font-mono" id="record-timer">
            {formatTime(recordTime)}
          </span>
        </div>

        {/* Recording progress */}
        {isRecording && (
          <div className="absolute bottom-32 left-4 right-4">
            <div className="bg-gray-800 rounded-full h-2 overflow-hidden">
              <div 
                className="bg-vinil-blue h-full transition-all duration-1000 ease-out"
                style={{ 
                  width: `${Math.min((recordTime / 60) * 100, 100)}%` 
                }}
              ></div>
            </div>
            <div className="text-center mt-2">
              <span className="text-gray-400 text-sm">
                {60 - recordTime}s restantes
              </span>
            </div>
          </div>
        )}
      </div>
      
      <BottomNavigation />
    </div>
  );
}
