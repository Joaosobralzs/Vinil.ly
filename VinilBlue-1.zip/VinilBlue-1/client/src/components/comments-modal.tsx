import { useState } from "react";
import { X, Send } from "lucide-react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import type { Video, Comment, User } from "@shared/schema";

interface CommentWithUser extends Comment {
  user: User;
}

interface CommentsModalProps {
  video: Video;
  isOpen: boolean;
  onClose: () => void;
}

export function CommentsModal({ video, isOpen, onClose }: CommentsModalProps) {
  const [newComment, setNewComment] = useState("");
  const queryClient = useQueryClient();

  const { data: comments = [] } = useQuery<CommentWithUser[]>({
    queryKey: ['/api/videos', video.id, 'comments'],
    queryFn: async () => {
      const response = await fetch(`/api/videos/${video.id}/comments`);
      const commentsData = await response.json();
      
      const commentsWithUsers = await Promise.all(
        commentsData.map(async (comment: Comment) => {
          const userResponse = await fetch(`/api/users/${comment.userId}`);
          const userData = await userResponse.json();
          return { ...comment, user: userData };
        })
      );
      
      return commentsWithUsers;
    },
    enabled: isOpen,
  });

  const addCommentMutation = useMutation({
    mutationFn: (text: string) => 
      apiRequest("POST", "/api/comments", {
        videoId: video.id,
        userId: "user3", // Current user
        text
      }),
    onSuccess: () => {
      setNewComment("");
      queryClient.invalidateQueries({ queryKey: ['/api/videos', video.id, 'comments'] });
      queryClient.invalidateQueries({ queryKey: ['/api/videos'] });
    }
  });

  const formatTimeAgo = (date: Date | string) => {
    const now = new Date();
    const commentDate = new Date(date);
    const diffInHours = Math.floor((now.getTime() - commentDate.getTime()) / (1000 * 60 * 60));
    
    if (diffInHours < 1) return "Agora mesmo";
    if (diffInHours < 24) return `${diffInHours}h`;
    const diffInDays = Math.floor(diffInHours / 24);
    return `${diffInDays}d`;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (newComment.trim() && !addCommentMutation.isPending) {
      addCommentMutation.mutate(newComment.trim());
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-end">
      <div className="w-full bg-white rounded-t-3xl max-h-[70vh] flex flex-col">
        {/* Comments Header */}
        <div className="flex items-center justify-between p-4 border-b border-gray-200">
          <h3 className="text-black font-semibold text-lg">
            {video.commentsCount} comentários
          </h3>
          <Button variant="ghost" size="sm" onClick={onClose}>
            <X className="w-6 h-6 text-gray-600" />
          </Button>
        </div>
        
        {/* Comments List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {comments.length === 0 ? (
            <p className="text-gray-500 text-center py-8">
              Seja o primeiro a comentar!
            </p>
          ) : (
            comments.map((comment) => (
              <div key={comment.id} className="flex space-x-3">
                <img 
                  src={comment.user.avatar || `https://api.dicebear.com/7.x/avataaars/svg?seed=${comment.user.username}`}
                  alt="Commenter" 
                  className="w-8 h-8 rounded-full object-cover" 
                />
                <div className="flex-1">
                  <div className="flex items-center space-x-2">
                    <span className="font-semibold text-gray-900 text-sm">
                      {comment.user.username}
                    </span>
                    <span className="text-gray-500 text-xs">
                      {formatTimeAgo(comment.createdAt!)}
                    </span>
                  </div>
                  <p className="text-gray-800 text-sm mt-1">{comment.text}</p>
                  <div className="flex items-center space-x-4 mt-2">
                    <button className="text-gray-500 text-xs hover:text-vinil-blue">
                      Responder
                    </button>
                    {comment.likesCount > 0 && (
                      <button className="text-gray-500 text-xs hover:text-red-500">
                        ❤️ {comment.likesCount}
                      </button>
                    )}
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
        
        {/* Comment Input */}
        <div className="p-4 border-t border-gray-200 bg-gray-50">
          <form onSubmit={handleSubmit} className="flex items-center space-x-3">
            <img 
              src="https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&h=100&fit=crop&crop=face"
              alt="Your avatar" 
              className="w-8 h-8 rounded-full object-cover" 
            />
            <Input
              type="text"
              placeholder="Adicione um comentário..."
              value={newComment}
              onChange={(e) => setNewComment(e.target.value)}
              className="flex-1 bg-white border-gray-300 rounded-full focus:ring-2 focus:ring-vinil-blue focus:border-transparent"
            />
            <Button 
              type="submit" 
              size="sm"
              className="bg-vinil-blue hover:bg-vinil-dark-blue text-white rounded-full"
              disabled={!newComment.trim() || addCommentMutation.isPending}
            >
              <Send className="w-4 h-4" />
            </Button>
          </form>
        </div>
      </div>
    </div>
  );
}
