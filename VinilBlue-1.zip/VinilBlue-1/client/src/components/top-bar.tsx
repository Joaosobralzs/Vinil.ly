import { Search, Menu } from "lucide-react";
import { useLocation } from "wouter";

export function TopBar() {
  const [, setLocation] = useLocation();

  return (
    <div className="absolute top-0 left-0 right-0 z-50 flex items-center justify-between p-4 pt-12 bg-gradient-to-b from-black/50 to-transparent">
      <button 
        className="p-2 hover:bg-gray-800 rounded-full transition-colors"
        onClick={() => setLocation("/search")}
      >
        <Search className="w-6 h-6 text-white" />
      </button>
      
      <div className="text-center">
        <h1 className="text-white text-2xl font-bold tracking-wider">
          vinil.<span className="text-vinil-blue">ly</span>
        </h1>
      </div>
      
      <button className="p-2 hover:bg-gray-800 rounded-full transition-colors">
        <Menu className="w-6 h-6 text-white" />
      </button>
    </div>
  );
}
