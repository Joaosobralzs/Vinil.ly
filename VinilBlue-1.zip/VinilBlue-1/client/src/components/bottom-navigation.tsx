import { Home, Search, Plus, Mail, User } from "lucide-react";
import { useLocation } from "wouter";
import { cn } from "@/lib/utils";

export function BottomNavigation() {
  const [location, setLocation] = useLocation();

  const navItems = [
    { id: "home", icon: Home, label: "Início", path: "/" },
    { id: "discover", icon: Search, label: "Descobrir", path: "/search" },
    { id: "create", icon: Plus, label: "", path: "/create", isSpecial: true },
    { id: "inbox", icon: Mail, label: "Inbox", path: "/inbox" },
    { id: "profile", icon: User, label: "Perfil", path: "/profile" },
  ];

  return (
    <div className="absolute bottom-0 left-0 right-0 bg-black border-t border-gray-800 flex items-center justify-around py-3 px-4 z-50">
      {navItems.map((item) => {
        const Icon = item.icon;
        const isActive = location === item.path;
        
        if (item.isSpecial) {
          return (
            <button
              key={item.id}
              className="flex flex-col items-center space-y-1 py-1"
              onClick={() => setLocation(item.path)}
            >
              <div className="bg-vinil-blue rounded-lg p-2">
                <Icon className="w-6 h-6 text-white" />
              </div>
            </button>
          );
        }

        return (
          <button
            key={item.id}
            className="flex flex-col items-center space-y-1 py-1"
            onClick={() => setLocation(item.path)}
          >
            <Icon 
              className={cn(
                "w-7 h-7",
                isActive ? "text-vinil-blue" : "text-gray-400"
              )} 
              fill={isActive ? "currentColor" : "none"}
            />
            <span className={cn(
              "text-xs font-medium",
              isActive ? "text-vinil-blue" : "text-gray-400"
            )}>
              {item.label}
            </span>
          </button>
        );
      })}
    </div>
  );
}
