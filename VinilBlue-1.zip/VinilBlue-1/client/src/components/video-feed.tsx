import { useEffect, useState, useRef } from "react";
import { useQuery } from "@tanstack/react-query";
import { VideoOverlay } from "./video-overlay";
import { CommentsModal } from "./comments-modal";
import type { Video, User } from "@shared/schema";

interface VideoWithUser extends Video {
  user: User;
}

export function VideoFeed() {
  const [currentVideoIndex, setCurrentVideoIndex] = useState(0);
  const [isCommentsOpen, setIsCommentsOpen] = useState(false);
  const [selectedVideo, setSelectedVideo] = useState<Video | null>(null);
  const videoFeedRef = useRef<HTMLDivElement>(null);
  
  const { data: videos = [] } = useQuery<VideoWithUser[]>({
    queryKey: ['/api/videos'],
    queryFn: async () => {
      const videosResponse = await fetch('/api/videos');
      const videosData = await videosResponse.json();
      
      // Fetch user data for each video
      const videosWithUsers = await Promise.all(
        videosData.map(async (video: Video) => {
          const userResponse = await fetch(`/api/users/${video.userId}`);
          const userData = await userResponse.json();
          return { ...video, user: userData };
        })
      );
      
      return videosWithUsers;
    }
  });

  // Touch handling for video swiping
  useEffect(() => {
    if (!videoFeedRef.current) return;

    let startY = 0;
    let currentY = 0;
    let isDragging = false;

    const handleTouchStart = (e: TouchEvent) => {
      startY = e.touches[0].clientY;
      isDragging = true;
    };

    const handleTouchMove = (e: TouchEvent) => {
      if (!isDragging || videos.length === 0) return;
      e.preventDefault();
      currentY = e.touches[0].clientY;
      const deltaY = currentY - startY;
      const resistance = 0.3;
      const translateY = deltaY * resistance;

      const videoItems = document.querySelectorAll('.video-item');
      if (videoItems[currentVideoIndex]) {
        (videoItems[currentVideoIndex] as HTMLElement).style.transform = `translateY(${translateY}px)`;
      }

      if (currentVideoIndex > 0 && videoItems[currentVideoIndex - 1]) {
        (videoItems[currentVideoIndex - 1] as HTMLElement).style.transform = `translateY(${translateY - window.innerHeight}px)`;
      }
      if (currentVideoIndex < videos.length - 1 && videoItems[currentVideoIndex + 1]) {
        (videoItems[currentVideoIndex + 1] as HTMLElement).style.transform = `translateY(${translateY + window.innerHeight}px)`;
      }
    };

    const handleTouchEnd = () => {
      if (!isDragging || videos.length === 0) return;
      isDragging = false;

      const deltaY = currentY - startY;
      const threshold = window.innerHeight * 0.2;

      if (Math.abs(deltaY) > threshold) {
        if (deltaY > 0 && currentVideoIndex > 0) {
          setCurrentVideoIndex(prev => prev - 1);
        } else if (deltaY < 0 && currentVideoIndex < videos.length - 1) {
          setCurrentVideoIndex(prev => prev + 1);
        }
      }
      updateVideoPositions();
    };

    const updateVideoPositions = () => {
      const videoItems = document.querySelectorAll('.video-item');
      videoItems.forEach((video, index) => {
        const offset = (index - currentVideoIndex) * window.innerHeight;
        (video as HTMLElement).style.transform = `translateY(${offset}px)`;
        (video as HTMLElement).style.transition = 'transform 0.5s ease-out';
        
        setTimeout(() => {
          (video as HTMLElement).style.transition = '';
        }, 500);
      });
    };

    const element = videoFeedRef.current;
    element.addEventListener('touchstart', handleTouchStart);
    element.addEventListener('touchmove', handleTouchMove);
    element.addEventListener('touchend', handleTouchEnd);

    // Keyboard navigation for development
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowUp' && currentVideoIndex > 0) {
        setCurrentVideoIndex(prev => prev - 1);
      } else if (e.key === 'ArrowDown' && currentVideoIndex < videos.length - 1) {
        setCurrentVideoIndex(prev => prev + 1);
      }
    };

    document.addEventListener('keydown', handleKeyDown);

    return () => {
      element.removeEventListener('touchstart', handleTouchStart);
      element.removeEventListener('touchmove', handleTouchMove);
      element.removeEventListener('touchend', handleTouchEnd);
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, [currentVideoIndex, videos.length]);

  // Update video positions when currentVideoIndex changes
  useEffect(() => {
    const videoItems = document.querySelectorAll('.video-item');
    videoItems.forEach((video, index) => {
      const offset = (index - currentVideoIndex) * window.innerHeight;
      (video as HTMLElement).style.transform = `translateY(${offset}px)`;
      (video as HTMLElement).style.transition = 'transform 0.5s ease-out';
      
      setTimeout(() => {
        (video as HTMLElement).style.transition = '';
      }, 500);
    });
  }, [currentVideoIndex]);

  const handleOpenComments = (video: Video) => {
    setSelectedVideo(video);
    setIsCommentsOpen(true);
  };

  if (videos.length === 0) {
    return (
      <div className="relative w-full h-full bg-black flex items-center justify-center">
        <p className="text-white text-lg">Carregando vídeos...</p>
      </div>
    );
  }

  return (
    <>
      <div ref={videoFeedRef} className="relative w-full h-full">
        {videos.map((video, index) => (
          <div
            key={video.id}
            className="video-item absolute inset-0 w-full h-full"
            style={{ transform: `translateY(${(index - currentVideoIndex) * window.innerHeight}px)` }}
          >
            <div 
              className="absolute inset-0 bg-cover bg-center"
              style={{ backgroundImage: `url(${video.thumbnailUrl})` }}
            >
              <div className="absolute inset-0 bg-black bg-opacity-20"></div>
            </div>
            
            <VideoOverlay
              video={video}
              user={video.user}
              onOpenComments={() => handleOpenComments(video)}
            />
          </div>
        ))}
      </div>

      {selectedVideo && (
        <CommentsModal
          video={selectedVideo}
          isOpen={isCommentsOpen}
          onClose={() => setIsCommentsOpen(false)}
        />
      )}
    </>
  );
}
