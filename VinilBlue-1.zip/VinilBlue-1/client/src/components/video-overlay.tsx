import { Heart, MessageCircle, Share, Music } from "lucide-react";
import type { Video, User } from "@shared/schema";
import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";

interface VideoOverlayProps {
  video: Video;
  user: User;
  onOpenComments: () => void;
}

export function VideoOverlay({ video, user, onOpenComments }: VideoOverlayProps) {
  const [isLiked, setIsLiked] = useState(false);
  const [isFollowing, setIsFollowing] = useState(false);
  const queryClient = useQueryClient();

  const likeMutation = useMutation({
    mutationFn: () => apiRequest("POST", "/api/likes", { userId: "user3", videoId: video.id }),
    onSuccess: () => {
      setIsLiked(!isLiked);
      queryClient.invalidateQueries({ queryKey: ['/api/videos'] });
    }
  });

  const followMutation = useMutation({
    mutationFn: () => apiRequest("POST", "/api/follows", { followerId: "user3", followingId: video.userId }),
    onSuccess: () => {
      setIsFollowing(!isFollowing);
    }
  });

  const formatCount = (count: number) => {
    if (count >= 1000000) {
      return `${(count / 1000000).toFixed(1)}M`;
    }
    if (count >= 1000) {
      return `${(count / 1000).toFixed(1)}K`;
    }
    return count.toString();
  };

  return (
    <div className="absolute inset-0 flex">
      {/* Left side - Video info */}
      <div className="flex-1 flex flex-col justify-end p-4 pb-24">
        <div className="space-y-3">
          {/* User info */}
          <div className="flex items-center space-x-3">
            <img 
              src={user.avatar || `https://api.dicebear.com/7.x/avataaars/svg?seed=${user.username}`}
              alt="User avatar" 
              className="w-12 h-12 rounded-full border-2 border-white object-cover" 
            />
            <div>
              <h3 className="font-semibold text-white text-lg">@{user.username}</h3>
              <Button 
                variant="secondary"
                size="sm"
                className="bg-vinil-blue text-white hover:bg-vinil-dark-blue border-0"
                onClick={() => followMutation.mutate()}
                disabled={followMutation.isPending}
              >
                {isFollowing ? "Seguindo" : "Seguir"}
              </Button>
            </div>
          </div>
          
          {/* Video description */}
          <p className="text-white text-base leading-relaxed">
            {video.description}
          </p>
          
          {/* Music info */}
          <div className="flex items-center space-x-2 bg-black bg-opacity-50 rounded-full px-3 py-2 w-fit">
            <Music className="w-4 h-4 text-vinil-gold" />
            <span className="text-white text-sm font-medium">
              {video.musicTitle} - {video.musicArtist || user.displayName}
            </span>
          </div>
        </div>
      </div>
      
      {/* Right side - Action buttons */}
      <div className="flex flex-col justify-end items-center space-y-6 p-4 pb-24">
        {/* Like button */}
        <div className="flex flex-col items-center space-y-1">
          <button 
            className="bg-gray-800 bg-opacity-70 rounded-full p-3 hover:bg-vinil-blue transition-colors"
            onClick={() => likeMutation.mutate()}
            disabled={likeMutation.isPending}
          >
            <Heart 
              className={`w-7 h-7 ${isLiked ? 'text-red-500 fill-red-500' : 'text-white'}`}
            />
          </button>
          <span className="text-white text-sm font-semibold">
            {formatCount(video.likesCount + (isLiked ? 1 : 0))}
          </span>
        </div>
        
        {/* Comment button */}
        <div className="flex flex-col items-center space-y-1">
          <button 
            className="bg-gray-800 bg-opacity-70 rounded-full p-3 hover:bg-vinil-blue transition-colors"
            onClick={onOpenComments}
          >
            <MessageCircle className="w-7 h-7 text-white" />
          </button>
          <span className="text-white text-sm font-semibold">
            {formatCount(video.commentsCount)}
          </span>
        </div>
        
        {/* Share button */}
        <div className="flex flex-col items-center space-y-1">
          <button className="bg-gray-800 bg-opacity-70 rounded-full p-3 hover:bg-vinil-blue transition-colors">
            <Share className="w-7 h-7 text-white" />
          </button>
          <span className="text-white text-sm font-semibold">
            {formatCount(video.sharesCount)}
          </span>
        </div>
        
        {/* Profile picture (rotating music) */}
        <div className="relative">
          <img 
            src={user.avatar || `https://api.dicebear.com/7.x/avataaars/svg?seed=${user.username}`}
            alt="Music avatar" 
            className="w-12 h-12 rounded-full border-2 border-white object-cover rotating-music"
          />
        </div>
      </div>
    </div>
  );
}
