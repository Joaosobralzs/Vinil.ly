import { useState, useRef } from "react";
import { X, Camera, Upload } from "lucide-react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import type { User } from "@shared/schema";

interface EditProfileModalProps {
  user: User;
  isOpen: boolean;
  onClose: () => void;
}

export function EditProfileModal({ user, isOpen, onClose }: EditProfileModalProps) {
  const [formData, setFormData] = useState({
    displayName: user.displayName,
    username: user.username,
    bio: user.bio || "",
    website: user.website || "",
    avatar: user.avatar || "",
  });
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const updateProfileMutation = useMutation({
    mutationFn: () => apiRequest("PATCH", `/api/users/${user.id}`, formData),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/users'] });
      onClose();
    }
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateProfileMutation.mutate();
  };

  const handleImageSelect = () => {
    fileInputRef.current?.click();
  };

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Verificar se é uma imagem
    if (!file.type.startsWith('image/')) {
      toast({
        title: "Erro",
        description: "Por favor, selecione apenas arquivos de imagem.",
        variant: "destructive",
      });
      return;
    }

    // Verificar tamanho do arquivo (máximo 5MB)
    if (file.size > 5 * 1024 * 1024) {
      toast({
        title: "Erro", 
        description: "A imagem deve ter no máximo 5MB.",
        variant: "destructive",
      });
      return;
    }

    // Converter para base64 ou URL temporária
    const reader = new FileReader();
    reader.onload = (event) => {
      const imageUrl = event.target?.result as string;
      setFormData(prev => ({ ...prev, avatar: imageUrl }));
    };
    reader.readAsDataURL(file);
  };

  const handleCancel = () => {
    setFormData({
      displayName: user.displayName,
      username: user.username,
      bio: user.bio || "",
      website: user.website || "",
      avatar: user.avatar || "",
    });
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-60 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl w-full max-w-md max-h-[90vh] overflow-y-auto">
        {/* Modal Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <h2 className="text-black text-xl font-bold">Editar Perfil</h2>
          <Button variant="ghost" size="sm" onClick={onClose}>
            <X className="w-6 h-6 text-gray-600" />
          </Button>
        </div>
        
        {/* Modal Content */}
        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          {/* Profile Picture */}
          <div className="text-center">
            <div className="relative inline-block">
              <img 
                src={formData.avatar || `https://api.dicebear.com/7.x/avataaars/svg?seed=${formData.username}`}
                alt="Profile picture" 
                className="w-24 h-24 rounded-full mx-auto mb-4 object-cover border-2 border-gray-200" 
              />
              <button
                type="button"
                onClick={handleImageSelect}
                className="absolute bottom-3 right-0 bg-vinil-blue text-white rounded-full p-2 shadow-lg hover:bg-vinil-dark-blue transition-colors"
              >
                <Camera className="w-4 h-4" />
              </button>
            </div>
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              onChange={handleImageChange}
              className="hidden"
            />
            <Button 
              type="button" 
              variant="link"
              className="text-vinil-blue hover:text-vinil-dark-blue"
              onClick={handleImageSelect}
            >
              <Upload className="w-4 h-4 mr-2" />
              Alterar Foto
            </Button>
          </div>
          
          {/* Form Fields */}
          <div className="space-y-4">
            <div>
              <Label className="text-gray-700 text-sm font-medium">
                Nome de Exibição
              </Label>
              <Input
                type="text"
                value={formData.displayName}
                onChange={(e) => setFormData({...formData, displayName: e.target.value})}
                className="w-full mt-2 border-gray-300 rounded-xl focus:ring-2 focus:ring-vinil-blue focus:border-transparent"
                required
              />
            </div>
            
            <div>
              <Label className="text-gray-700 text-sm font-medium">
                Nome de Usuário
              </Label>
              <Input
                type="text"
                value={formData.username}
                onChange={(e) => setFormData({...formData, username: e.target.value})}
                className="w-full mt-2 border-gray-300 rounded-xl focus:ring-2 focus:ring-vinil-blue focus:border-transparent"
                required
              />
            </div>
            
            <div>
              <Label className="text-gray-700 text-sm font-medium">
                Bio
              </Label>
              <Textarea
                rows={3}
                value={formData.bio}
                onChange={(e) => setFormData({...formData, bio: e.target.value})}
                placeholder="Conte um pouco sobre você..."
                className="w-full mt-2 border-gray-300 rounded-xl focus:ring-2 focus:ring-vinil-blue focus:border-transparent resize-none"
                maxLength={150}
              />
              <div className="text-gray-500 text-sm mt-1">
                {formData.bio.length}/150 caracteres
              </div>
            </div>
            
            <div>
              <Label className="text-gray-700 text-sm font-medium">
                Website
              </Label>
              <Input
                type="url"
                value={formData.website}
                onChange={(e) => setFormData({...formData, website: e.target.value})}
                placeholder="https://seusite.com"
                className="w-full mt-2 border-gray-300 rounded-xl focus:ring-2 focus:ring-vinil-blue focus:border-transparent"
              />
            </div>
          </div>
          
          {/* Action Buttons */}
          <div className="flex space-x-3 pt-4">
            <Button 
              type="button"
              variant="secondary"
              className="flex-1"
              onClick={handleCancel}
            >
              Cancelar
            </Button>
            <Button 
              type="submit"
              className="flex-1 bg-vinil-blue hover:bg-vinil-dark-blue"
              disabled={updateProfileMutation.isPending}
            >
              {updateProfileMutation.isPending ? "Salvando..." : "Salvar"}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}
