# Overview

This is a TikTok-like social video platform called "vinil.ly" built with a modern full-stack architecture. The application allows users to create, share, and interact with short-form videos through features like liking, commenting, following, and video feeds. It's designed as a mobile-first social media platform with a dark theme aesthetic and smooth video browsing experience.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **React 18** with TypeScript for the client application
- **Vite** as the build tool and development server for fast hot module replacement
- **Wouter** for client-side routing instead of React Router for lightweight navigation
- **TanStack Query** for server state management, caching, and data fetching
- **Tailwind CSS** with shadcn/ui component library for styling and UI components
- **Mobile-first responsive design** with touch gesture support for video swiping
- Component-based architecture with reusable UI components organized in a clear folder structure

## Backend Architecture
- **Express.js** server with TypeScript for API endpoints
- **RESTful API design** with structured routes for users, videos, comments, likes, and follows
- **In-memory storage implementation** (MemStorage class) for development/demo purposes
- **Modular route handling** with clean separation of concerns between routing and storage
- **Request/response logging middleware** for debugging and monitoring
- **Error handling middleware** for consistent error responses

## Data Storage Solutions
- **PostgreSQL** configured as the primary database using Drizzle ORM
- **Neon Database** (@neondatabase/serverless) as the PostgreSQL provider
- **Drizzle ORM** for type-safe database operations and schema management
- **Database schema** includes tables for users, videos, comments, likes, and follows with proper relationships
- **Zod integration** for runtime schema validation using drizzle-zod
- **Database migrations** handled through Drizzle Kit for version control

## Authentication and Authorization
- **Session-based authentication** configured with connect-pg-simple for PostgreSQL session storage
- Basic user management system with user creation, updates, and profile management
- No complex auth providers - uses simple user ID based system for development

## External Dependencies

### UI and Styling
- **Radix UI** primitives for accessible, unstyled UI components
- **Lucide React** for consistent iconography
- **Tailwind CSS** for utility-first styling with custom design system variables
- **class-variance-authority** and **clsx** for conditional styling
- **date-fns** for date manipulation and formatting

### Development and Build Tools
- **TypeScript** for type safety across the entire stack
- **ESBuild** for fast production builds
- **PostCSS** with Autoprefixer for CSS processing
- **TSX** for development server with TypeScript support
- **Replit integration** with specific plugins for development environment

### State Management and Data Fetching
- **TanStack React Query** for server state management and caching
- **React Hook Form** with Hookform Resolvers for form validation
- **Embla Carousel** for touch-friendly carousel implementations

### Database and ORM
- **Drizzle ORM** with PostgreSQL dialect for database operations
- **Neon Database serverless** for cloud PostgreSQL hosting
- **Drizzle Kit** for migrations and database management tooling
- **connect-pg-simple** for PostgreSQL-backed session storage